package com.example.BackEndCVMatchMaking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackEndCvMatchMakingApplicationTests {

	@Test
	void contextLoads() {
	}

}
